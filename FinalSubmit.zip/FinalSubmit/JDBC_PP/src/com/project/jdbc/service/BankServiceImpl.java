package com.project.jdbc.service;

import com.project.jdbc.bean.Customer;
import com.project.jdbc.bean.Transaction;
import com.project.jdbc.dao.BankDAOImpl;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankServiceImpl implements IBankService{

    BankDAOImpl bankDao = new BankDAOImpl();
    
    @Override
    public void createAccount(Customer customer, Transaction transaction) {
        bankDao.createAccount(customer, transaction);
    }

    @Override
    public int showbalance(Long accountNum) {
    ResultSet resultSet =  bankDao.getAccountDetails(accountNum);
        try {
        	while(resultSet.next()) {
            return resultSet.getInt(5);}
        } catch (SQLException ex) {
        }
        return 0;
    }
    
    @Override
    public boolean contain(Long accountNum) {
       ResultSet resultSet =  bankDao.getAccountDetails(accountNum);
       try {
		while(resultSet.next()) {
		   if(resultSet == null){
		   return false;}
		    else
		       return true;
		}
	} catch (SQLException e) {
	}return false;
       }

    @Override
    public boolean checkPin(int pin, Long accountNum) {
    ResultSet resultSet =  bankDao.getAccountDetails(accountNum);
        try {
        	while(resultSet.next()) {
            if(pin==resultSet.getInt(4)){
            return true;}}
        } 
        catch (SQLException ex) {
        }
        return false;
    }

    @Override
    public void depositeBalance(long accountNumber, int deposite, Transaction transaction) {
       ResultSet resultSet = bankDao.getAccountDetails(accountNumber);
        try {
        	while(resultSet.next()) {
            int totalbalance= resultSet.getInt(5) + deposite;
             bankDao.depositeBalance(accountNumber, totalbalance, deposite, transaction);
        	} } catch (SQLException ex) {
        }
    }

    @Override
    public int withdraw(long accountNum, int withdraw, Transaction transaction) {
      
        try {
        	ResultSet resultSet = bankDao.getAccountDetails(accountNum);
        	while(resultSet.next()) {
        	if(resultSet.getInt(5)>withdraw){
            int totalbalance= resultSet.getInt(5) - withdraw;
            return bankDao.withdraw(accountNum, totalbalance, withdraw, transaction);
             }else return 0;
        }} catch (SQLException ex) {
           return 0;
        }
       return 0;
    }

    @Override
    public int fundTransfer(Long fromAccountNo, Long toAccountNo, int money, Transaction transaction1, Transaction transaction2) {
     ResultSet resultSet = bankDao.getAccountDetails(fromAccountNo);
        try {
        	int totalbalance1 = 0;
        	while(resultSet.next()) {
            if(resultSet.getInt(5)>money){
            int totalbalance= resultSet.getInt(5) - money;
            ResultSet resultSet1 = bankDao.getAccountDetails(toAccountNo);
            while(resultSet1.next()) {
            totalbalance1 = resultSet1.getInt(5) + money;}
            return bankDao.transfer(fromAccountNo, totalbalance, toAccountNo, totalbalance1, transaction1, transaction2);
            }else return 0;}
        } catch (SQLException ex) {
             return 0;
        }return 0;
    }

    @Override
    public ResultSet printTransaction(long transAccNo) {
    return bankDao.printTransaction(transAccNo);
    }
}
