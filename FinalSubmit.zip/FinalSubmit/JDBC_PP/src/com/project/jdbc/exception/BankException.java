package com.project.jdbc.exception;

public class BankException extends RuntimeException{

	public BankException() {
		// TODO Auto-generated constructor stub
	}

	public BankException(String message) {
		super(message);
	}
	
}
