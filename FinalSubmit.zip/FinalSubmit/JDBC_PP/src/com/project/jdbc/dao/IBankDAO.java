package com.project.jdbc.dao;

import java.sql.ResultSet;

import com.project.jdbc.bean.Customer;
import com.project.jdbc.bean.Transaction;

public interface IBankDAO {
	
	public void createAccount(Customer customer, Transaction transaction);
	public ResultSet getAccountDetails(long accountno);
	public void depositeBalance(long accountNumber, int totalbalance, int deposite, Transaction transaction);
	public int withdraw(long accountNum, int totalbalance, int withdraw, Transaction transaction);
	public int transfer(Long fromAccountNo, int totalbalance, Long toAccountNo, int totalbalance1,Transaction transaction, Transaction transaction1);
	public ResultSet getAccountTransactionDetails(long accountno);
	public ResultSet printTransaction(long transAccNo) ;

}
