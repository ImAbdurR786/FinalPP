package com.cg.project.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customers")
public class Customer {
@Id
@Column(name="Customer_accountN0",length=20)
private long accountNo;
@Column(name="Customer_name",length=20)
private String name;
@Column(name="Customer_number",length=20)
private String number;
@Column(name="Customer_pin",length=20)
private int pin;
@Column(name="Customer_balance",length=20)
private int balance;

    public Customer(){
    }
    
    public Customer(String name, String number, int pin, int balance) {
        this.name = name;
        this.number = number;
        this.pin = pin;
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    @Override
    public String toString() {
        return "Customer{" + "accountNo=" + accountNo + ", name=" + name + ", number=" + number + ", pin=" + pin + ", balance=" + balance + '}';
    }

}

