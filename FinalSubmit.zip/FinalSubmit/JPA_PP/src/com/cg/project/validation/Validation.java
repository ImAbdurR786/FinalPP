package com.cg.project.validation;
import java.util.regex.Pattern;

import com.cg.project.exception.NameException;
import com.cg.project.exception.NumberException;

public class Validation {

    public boolean isNameValid(String name) {
    if(name.length()>4){
     if(Pattern.matches("([A-Z])*([a-z])*", name)){
        return true;
          }else {
        	  try {
              	throw new NameException("Name is not Valid");
              }catch(NameException ex) {
              	System.out.println(ex.getMessage());
              	return false;
              }
     }}
     else
       {
    	  try {
            	throw new NameException("Name length should be minimum 5");
            }catch(NameException ex) {
            	System.out.println(ex.getMessage());
            	return false;
            }
       }
 
    }

    public boolean isNumberValid(String number) {
        if (number.matches("^[6-9][0-9]{9}$"))
            {
                return true;
            }
        else{
        try {
        	throw new NumberException("Number is not Valid");
        }catch(NumberException ex) {
        	System.out.println(ex.getMessage());
        	return false;
        }
        }
 
    }
 }