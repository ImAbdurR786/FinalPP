/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.project.dao;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import java.util.List;

public interface BankDAO {
	// public Customer getCustomerByAccountNo(Long accountNum);
	public void createAccount(Customer customer);

	public int showbalance(Long showaccountNo);

	public void depositeBalance(Customer customer, Transaction transaction);

	public void withdrawBalance(Customer customer, Transaction transaction);

	public void fundTransfer(Customer customer1, Customer customer2, Transaction transaction1,
			Transaction transaction2);

	public List<Transaction> printTransaction(long transAccNo);

	public boolean contain(Long accountNo);

	public boolean checkPin(int pin, Long accountNo);

	public Customer getCustomerByAccountNo(Long accountNum);
}
