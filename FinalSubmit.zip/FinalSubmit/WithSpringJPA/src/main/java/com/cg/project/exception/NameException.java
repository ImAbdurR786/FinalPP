package com.cg.project.exception;

public class NameException extends RuntimeException {

    public NameException(String message) {
     super(message);
    }
    
}
