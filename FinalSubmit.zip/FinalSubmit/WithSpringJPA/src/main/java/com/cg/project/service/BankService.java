package com.cg.project.service;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import java.util.List;

public interface BankService {
  public void createAccount(Customer customer);
  public int showbalance(Long accountNo);
   public void depositeBalance(long accountNumber, int deposite,Transaction transaction);
   public int withdraw(long accountNu, int withdraw, Transaction transaction);
   public int fundTransfer(Long fromAcc, Long toAcc, int money, Transaction transaction1, Transaction transaction2);
    public List<Transaction> printTransaction(long transAccNo);
}
