package com.cg.collection.pp.service;

import com.cg.collection.pp.bean.Customer;

public interface IBankService {
    public long createAccount(Customer customer);
    public int showBalance(long acntNo, int pinNo);
    public int  depositeMoney(long accountNumber, int amountDeposite, String trans);
    public int withdrawMoney(long accountNumbr, int amountWithdraw,String trans);
    public int fundTransfer(long fromaccountNo, long toaccountNo, int moneyTransfer,String trans1, String trans2);
    public String printTransaction(long acountNo);
   }
