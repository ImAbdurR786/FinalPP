package com.cg.controller;
 
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Customer;
import com.cg.entities.Transacations;
import com.cg.exception.AccountNotFoundException;
import com.cg.service.IService;

@RestController
@RequestMapping("/bankController")
@CrossOrigin(origins="http://localhost:4200")

public class BankController {
	
    @Autowired
	IService service;

        @PostMapping("/createAccount")
	public Customer createAccount(@Valid @RequestBody Customer customer) throws AccountNotFoundException {
            Transacations trans = new Transacations("Account Created", customer.getBal());
            trans.setAccountNo(customer.getAccNo());
            return service.createAccount(customer,trans);
	}

	@GetMapping("/showBalance/{accountNo}/{pin}")
	public ResponseEntity<String> showBalance(@PathVariable Long accountNo, @PathVariable String pin) throws AccountNotFoundException {
		Double balance = service.showBalance(accountNo,pin);
		return new ResponseEntity<String>("Available balance: " + balance, HttpStatus.OK);
	}

	@PutMapping("/deposit/{accountNo}/{pin}/{amount}")
	public ResponseEntity<String> deposit(@Valid @PathVariable Long accountNo,@PathVariable String pin, @PathVariable Double amount) throws AccountNotFoundException {
		Transacations trans = new Transacations("Amount Deposite", amount);
                trans.setAccountNo(accountNo);
                Double balance = service.deposit(accountNo, amount, pin, trans);
		return new ResponseEntity<String>("After deposited: " + balance, HttpStatus.OK);
	}

	@PutMapping("/withdraw/{accountNo}/{pin}/{amount}")
	public ResponseEntity<String> withdraw(@Valid @PathVariable Long accountNo,@PathVariable String pin, @PathVariable Double amount) throws AccountNotFoundException {
		 Transacations trans = new Transacations("Amount Withdraw", amount);
         trans.setAccountNo(accountNo);
		Double balance = service.withdraw(accountNo, amount,pin,  trans   );
		return new ResponseEntity<String>("After withdrawn: " + balance, HttpStatus.OK);
	}

	@PutMapping("/fundTransfer/{accountNo}/{pin}/{amount}/{accountNo1}")
	public ResponseEntity<String> fundTransfer(@Valid @PathVariable Long accountNo, @PathVariable String pin, @PathVariable Double amount,
			@PathVariable Long accountNo1) throws AccountNotFoundException {
		Transacations trans1 = new Transacations("Amount Transfer", amount);
        trans1.setAccountNo(accountNo);
        Transacations trans2 = new Transacations("Amount Recieve", amount);
        trans2.setAccountNo(accountNo1);
		Double balance = service.fundTransfer(accountNo,pin, amount, accountNo1,trans1,trans2);
		return new ResponseEntity<String>("Transaction Completed\n*****************************"
				+ "\nAmount transferred: "+amount
				+ "\nDeposited account number: "+accountNo1+"\n*****************************\n"
				+ "After transaction: " +balance
				+ "\n*****************************", HttpStatus.OK);
	}

	@GetMapping("/printTransactions/{accountNo}/{pin}")
	public List<Transacations> printTransaction(@PathVariable Long accNo, @PathVariable String pin) throws AccountNotFoundException {
		return service.printTransaction(accNo,pin);
	}
}
