package com.cg.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entities.Customer;

public interface IBankDao extends JpaRepository<Customer, Long> {

//        @Query("select cus.bal from Customer cus where cus.accNo =:c")
//	Optional<Double> showBalance(@Param("c") Long accNo);
//        
//       
//        
//        @Query("select accNo,name from Customer where accNo =?1")
//	Optional<Customer> accountsDetails(@Param("c") Long accNo);

//	
//	@Query("select accNo,name from CustomerDetails where accNo =?1")
//	Optional<Customer> accountsDetails(@Param("c") Long accNo);
//
//	@Query("select be.bal from CustomerDetails be where be.accNo =?1")
//	Optional<Double> showBalance(@Param("c") Long accNo);
}
