import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Customer } from '../customer';
import { race } from 'q';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  bankService: BankService;
  customer: Customer;

  constructor(bankService: BankService) {
    this.bankService = bankService;
  }
 
  accn: number;
  model : any ={};
 
  add(data: any) {
            this.customer = new Customer(data.ename, data.epin, data.ephone, data.ebalance);
            this.bankService.add(this.customer).subscribe
            (data=>{
              this.accn = data.accNo;
              console.log(data.accNo);
            });
           }
  ngOnInit() {
  }

}
