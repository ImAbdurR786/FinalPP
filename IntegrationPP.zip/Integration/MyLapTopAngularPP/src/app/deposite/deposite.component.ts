import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-deposite',
  templateUrl: './deposite.component.html',
  styleUrls: ['./deposite.component.css']
})
export class DepositeComponent implements OnInit {

  bankService: BankService;
  depositString: String;
  
  constructor(bankService: BankService) {
    this.bankService = bankService;
   }

  depositeBalance(data: any){
    this.bankService.depositeBalance(data).subscribe
    (data=>{
      this.depositString = data;
      console.log(data);
    });
  }
  ngOnInit() {
  }

}